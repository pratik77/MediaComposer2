package com.cg.mp.presentation;

import java.sql.Date;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.Scanner;

import com.cg.mp.dto.ArtistSongAssoc;
import com.cg.mp.dto.ComposerMasterDTO;
import com.cg.mp.dto.ComposerSongAssoc;
import com.cg.mp.dto.SongMasterDTO;
import com.cg.mp.exception.SongException;
import com.cg.mp.service.ISongService;
import com.cg.mp.service.SongService;

public class ClientSongs {

	public void clientSongsTest(int choice1,int userId) {
		// TODO Auto-generated method stub
		ISongService songService=new SongService();
		ComposerMasterDTO composerMasterDTO=new ComposerMasterDTO();
		SongMasterDTO songMasterDTO = new SongMasterDTO();
		Scanner sc = new Scanner(System.in);
		int choice2,choice3,composerId=0;
		char choice5;
		String password;
		DateTimeFormatter formatter=null;
		switch(choice1)
		{
		
					case 6:
						ComposerSongAssoc composerSongAssoc = new ComposerSongAssoc();
						System.out.println("********************************");
						System.out.println("Associate Song to Composer");
						System.out.println("********************************");
						System.out.println("Enter Composer ID");
						int cId=sc.nextInt();
						composerSongAssoc.setComposerId(cId);


						System.out.println("Enter song Id");
						int sId = sc.nextInt();
						composerSongAssoc.setSongId(sId);

						try {
							System.out.println(songService.compSongAssoc(composerSongAssoc, userId));
						} catch (SongException e) {

							System.out.println(e.getMessage());
						}
						break;

					case 12:
						ArtistSongAssoc artistSongAssoc = new ArtistSongAssoc();
						System.out.println("********************************");
						System.out.println("Associate Song to Artist");
						System.out.println("********************************");
						System.out.println("Enter Artist ID");
						int aId=sc.nextInt();
						artistSongAssoc.setArtistId(aId);;


						System.out.println("Enter song Id");
						int songId = sc.nextInt();
						artistSongAssoc.setSongId(songId);

						try {
							System.out.println(songService.artistSongAssoc(artistSongAssoc, userId));
						} catch (SongException e) {

							System.out.println(e.getMessage());
						}
						
						break;
						
					case 13:
						System.out.println("********************************");
						System.out.println("Adding New Song");
						System.out.println("********************************");
						System.out.println("Enter Song Name");
						String songName=sc.next()+sc.nextLine();
						songMasterDTO.setSongName(songName);
						String songDuration;
						int cnt=0;
						do{
							System.out.println("Enter song duration");
							songDuration=sc.next();
							songMasterDTO.setSongDuration(songDuration);
							if(songService.checkSongDuration(songDuration)){
								break;
							}else{

								cnt++;
							}
						}while(cnt<3);
						try
						{
							if(cnt==3)
								throw new SongException();
						}
						catch(SongException e)
						{
							System.out.println("Entered Song Duration is not valid");
							System.exit(0);
						}

						try {

							songService.addSong(songMasterDTO, userId);
							System.out.println("song added successfully");
						} catch (SongException e) {
							// TODO Auto-generated catch block
							System.out.println(e.getMessage());
						}
						break;

					}


					
	}

	}
