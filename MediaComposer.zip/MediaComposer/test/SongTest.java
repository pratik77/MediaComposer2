import static org.junit.Assert.assertEquals;

import java.sql.Date;

import org.junit.Before;
import org.junit.Test;

import com.cg.mp.dao.ComposerDAO;
import com.cg.mp.dao.IComposerDAO;
import com.cg.mp.dto.ComposerMasterDTO;
import com.cg.mp.exception.SongException;

public class SongTest {
	
	int id=0;
	IComposerDAO composerDAO=new ComposerDAO();
	ComposerMasterDTO composerMasterDTO=new ComposerMasterDTO();
	@Before
	public void setUp() throws Exception {
		composerMasterDTO.setComposerName("TestName");
		composerMasterDTO.setComposerBornDate(Date.valueOf("2017-02-01"));
		composerMasterDTO.setComposerCaeipiNumber("1234567");
		composerMasterDTO.setComposerMusicSocId("e34");
		id=composerDAO.addComposer(composerMasterDTO, 100001);
		
	}
	
	@Test
	public void loginAdminTest() {
		try {
			assertEquals("admin",composerDAO.checkLogin(100001, "zyrus"));
		} catch (SongException e) {
			// TODO Auto-generated catch block
			System.out.println(e.getMessage());
		}
	}
	
	@Test
	public void loginUserTest() {
		try {
			assertEquals("user",composerDAO.checkLogin(100006, "zyrus"));
		} catch (SongException e) {
			// TODO Auto-generated catch block
			System.out.println(e.getMessage());
		}
	}
	
	@Test
	public void insertComposerTest() {
		
		composerMasterDTO.setComposerName("TestName");
		composerMasterDTO.setComposerBornDate(Date.valueOf("2017-02-01"));
		composerMasterDTO.setComposerCaeipiNumber("1234567");
		composerMasterDTO.setComposerMusicSocId("e34");
		
		try {
			assertEquals(++id,composerDAO.addComposer(composerMasterDTO, 100001));
		} catch (SongException e) {
			// TODO Auto-generated catch block
			System.out.println(e.getMessage());
		}
	}

}
